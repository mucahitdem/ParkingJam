﻿using Scripts.SoundManagement;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Scripts.BaseGameScripts.UiManagement.BaseUiItemManagement
{
    public abstract class BaseClickableImage : BaseUiItem, IPointerClickHandler
    {
        [SerializeField]
        private bool playSoundOnTap = true;

        [SerializeField]
        private bool useCustomSound;

        [ShowIf("useCustomSound")]
        [SerializeField]
        private string audioId;

        public virtual void OnPointerClick(PointerEventData eventData)
        {
            PlaySound();
        }

        protected virtual void PlaySound()
        {
            if(!playSoundOnTap)
                return;
            SoundManager.Instance.PlayAudio(useCustomSound ? audioId : Defs.AUDIO_BUTTON_CLICK);
        }
    }
}