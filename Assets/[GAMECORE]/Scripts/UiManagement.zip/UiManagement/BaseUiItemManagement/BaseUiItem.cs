﻿using Scripts.BaseGameScripts.ComponentManagement;
using Sirenix.OdinInspector;
using Sirenix.Utilities;
using UnityEngine;

namespace Scripts.BaseGameScripts.UiManagement.BaseUiItemManagement
{
    public abstract class BaseUiItem : BaseComponent
    {
        [SerializeField]
        private bool setIdViaInspector;

        [ShowIf("setIdViaInspector")]
        [SerializeField]
        protected string uiItemId;

        [ShowInInspector]
        public string UiItemId
        {
            get
            {
                if (uiItemId.IsNullOrWhitespace())
                    try
                    {
                        uiItemId = GetUiId();
                    }
                    catch
                    {
                        uiItemId = "";
                    }

                return uiItemId;
            }
        }

        public virtual void ShowUi()
        {
            Go.SetActive(true);
        }

        public virtual void HideUi()
        {
            Go.SetActive(false);
        }

        [Button]
        protected abstract string GetUiId();
    }
}