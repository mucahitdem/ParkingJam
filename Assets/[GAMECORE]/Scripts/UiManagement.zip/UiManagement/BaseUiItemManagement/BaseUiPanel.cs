﻿namespace Scripts.BaseGameScripts.UiManagement.BaseUiItemManagement
{
    public class BaseUiPanel : BaseUiItem
    {
        protected override string GetUiId()
        {
            return null;
        }
    }
}